module.exports = {
    secret: "foodpal-khana-khazana-key"
}